var height = 42
if (height >= 42) {
    console.log ("Get on that ride, kiddo!")
}
else {
    console.log ("Sorry kiddo. Maybe next year.")
}

// Strech Feature 1
var height = 42
var age = 10
if (height >= 42 && age >= 10) {
    console.log ("Get on that ride, kiddo!")
}
else {
    console.log ("Sorry kiddo. Maybe next year.")
}

//Strech Feature 2
var height = 42
var age = 10
if (height >= 42 || age >= 10) {
    console.log ("Get on that ride, kiddo!")
}
else {
    console.log ("Sorry kiddo. Maybe next year.")
}