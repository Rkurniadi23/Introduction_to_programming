/* Complete the function in the code below to console log all 
numbers down from 100 to 1. */

function print68to9() {
    
}
print68to9()




/* Complete the function in the code below to return the largest 
value of an array. For example:
Given: [3, 6, 4, 9, 2]
Return: 9
*/

function findLargest(arr) {
  
}
findLargest([10, 3, 3.6, 7, 31, 8])




/* Complete the function in the code below to return a 
count of all values in the array larger than another number "y".
Given: [3, 6, 4, 9, 2], 5
Return: 2
*/

function countGreaterThanY(arr, y) {

}
countGreaterThanY([9, 4, 3.6, 1, 20, 16], 5)
