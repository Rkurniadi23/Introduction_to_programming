var height = 42 //height of a rider is 42
var age = 11 //age of a rider is 10
if (height => 42, age > 10) {
    console.log ("Put on your seat belt!")
}
else {
    console.log ("NO RIDE!")
}
//A person has to be at least 42 inches and over the age of 10 to get on the ride