// It is to store the value 0 into likeCount - what would this variable do?
var likeCount = 0;
// Nothing, since it doesn't print out anything out from the function - what would be the function of this code block?
function increaseLikes() {
    // Nothing, since it doesn't print out anything out from the function - what is this sort operation for?
    likeCount = likeCount + 1;
}