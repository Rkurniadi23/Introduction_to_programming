export function main() {
    function greeting(){
        return ("Hello World");
    }
    var word = greeting();
    console.log(word);
}